﻿
namespace CadastroBeta
{
    partial class FrmSplashScreen
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.PicBcadastro = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.PicBcadastro)).BeginInit();
            this.SuspendLayout();
            // 
            // PicBcadastro
            // 
            this.PicBcadastro.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PicBcadastro.Image = global::CadastroBeta.Properties.Resources.net;
            this.PicBcadastro.Location = new System.Drawing.Point(12, 12);
            this.PicBcadastro.Name = "PicBcadastro";
            this.PicBcadastro.Size = new System.Drawing.Size(1014, 455);
            this.PicBcadastro.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PicBcadastro.TabIndex = 0;
            this.PicBcadastro.TabStop = false;
            // 
            // FrmSplashScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1024, 496);
            this.Controls.Add(this.PicBcadastro);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmSplashScreen";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SplashScreen";
            this.Shown += new System.EventHandler(this.FrmSplashScreen_Shown);
            ((System.ComponentModel.ISupportInitialize)(this.PicBcadastro)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox PicBcadastro;
    }
}

