﻿
namespace CircodeApps2
{
    partial class FrmMega
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMega));
            this.BtnSortear = new System.Windows.Forms.Button();
            this.BtnSair = new System.Windows.Forms.Button();
            this.LblVerificar = new System.Windows.Forms.Label();
            this.LsbMega = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // BtnSortear
            // 
            this.BtnSortear.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSortear.Location = new System.Drawing.Point(674, 44);
            this.BtnSortear.Name = "BtnSortear";
            this.BtnSortear.Size = new System.Drawing.Size(75, 23);
            this.BtnSortear.TabIndex = 0;
            this.BtnSortear.Text = "Sortear";
            this.BtnSortear.UseVisualStyleBackColor = true;
            this.BtnSortear.Click += new System.EventHandler(this.BtnSortear_Click);
            // 
            // BtnSair
            // 
            this.BtnSair.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSair.Location = new System.Drawing.Point(674, 107);
            this.BtnSair.Name = "BtnSair";
            this.BtnSair.Size = new System.Drawing.Size(75, 23);
            this.BtnSair.TabIndex = 1;
            this.BtnSair.Text = "Sair";
            this.BtnSair.UseVisualStyleBackColor = true;
            this.BtnSair.Click += new System.EventHandler(this.BtnSair_Click);
            // 
            // LblVerificar
            // 
            this.LblVerificar.AutoSize = true;
            this.LblVerificar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblVerificar.Location = new System.Drawing.Point(39, 21);
            this.LblVerificar.Name = "LblVerificar";
            this.LblVerificar.Size = new System.Drawing.Size(143, 13);
            this.LblVerificar.TabIndex = 2;
            this.LblVerificar.Text = "Números em verificação";
            this.LblVerificar.Click += new System.EventHandler(this.label1_Click);
            // 
            // LsbMega
            // 
            this.LsbMega.FormattingEnabled = true;
            this.LsbMega.Location = new System.Drawing.Point(12, 44);
            this.LsbMega.Name = "LsbMega";
            this.LsbMega.Size = new System.Drawing.Size(195, 251);
            this.LsbMega.TabIndex = 3;
            this.LsbMega.SelectedIndexChanged += new System.EventHandler(this.LsbMega_SelectedIndexChanged);
            // 
            // FrmMega
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.LsbMega);
            this.Controls.Add(this.LblVerificar);
            this.Controls.Add(this.BtnSair);
            this.Controls.Add(this.BtnSortear);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmMega";
            this.Text = "Mega Sena";
            this.Load += new System.EventHandler(this.FrmMega_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnSortear;
        private System.Windows.Forms.Button BtnSair;
        private System.Windows.Forms.Label LblVerificar;
        private System.Windows.Forms.ListBox LsbMega;
    }
}