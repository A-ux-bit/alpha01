﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CircodeApps2
{
    public partial class FrmConverter : Form
    {
        public FrmConverter()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double valor, rdolar, rien, rlibra, rfranco;
            valor = Convert.ToDouble(TxtReal.Text);
            rdolar = valor / 5.53;
            rien = valor / 20.33;
            rlibra = valor / 0.14;
            rfranco = valor / 0.17;
            TxtDolar.Text = rdolar.ToString("N2");
            TxtIen.Text = rien.ToString("N2");
            TxtLibra.Text = rlibra.ToString("N2");
            TxtFranco.Text = rfranco.ToString("N2");
            TxtReal.Text = "";
            this.ActiveControl = TxtReal;
            TxtReal.Focus();
        }

        private void FrmConverter_Load(object sender, EventArgs e)
        {
            this.ActiveControl = TxtReal;
            TxtReal.Focus();
        }

        private void TxtReal_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && e.KeyChar != (char)8 && e.KeyChar != (char)44)
            {
                e.Handled = true;
            }
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
