﻿
namespace CircodeApps2
{
    partial class FrmVeiculo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblValorPago = new System.Windows.Forms.Label();
            this.BtnCalcular = new System.Windows.Forms.Button();
            this.TxtValor = new System.Windows.Forms.TextBox();
            this.BtnSair = new System.Windows.Forms.Button();
            this.LblMensal = new System.Windows.Forms.Label();
            this.LblAnual = new System.Windows.Forms.Label();
            this.TxtMensal = new System.Windows.Forms.TextBox();
            this.TxtAnual = new System.Windows.Forms.TextBox();
            this.Lblano = new System.Windows.Forms.Label();
            this.TxtAno = new System.Windows.Forms.TextBox();
            this.LblReal = new System.Windows.Forms.Label();
            this.TxtReal = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // LblValorPago
            // 
            this.LblValorPago.AutoSize = true;
            this.LblValorPago.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblValorPago.Location = new System.Drawing.Point(50, 52);
            this.LblValorPago.Name = "LblValorPago";
            this.LblValorPago.Size = new System.Drawing.Size(143, 13);
            this.LblValorPago.TabIndex = 0;
            this.LblValorPago.Text = "Valor pago pelo veículo";
            this.LblValorPago.Click += new System.EventHandler(this.LblValorPago_Click);
            // 
            // BtnCalcular
            // 
            this.BtnCalcular.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnCalcular.Location = new System.Drawing.Point(658, 120);
            this.BtnCalcular.Name = "BtnCalcular";
            this.BtnCalcular.Size = new System.Drawing.Size(75, 23);
            this.BtnCalcular.TabIndex = 1;
            this.BtnCalcular.Text = "Calcular";
            this.BtnCalcular.UseVisualStyleBackColor = true;
            this.BtnCalcular.Click += new System.EventHandler(this.BtnCalcular_Click);
            // 
            // TxtValor
            // 
            this.TxtValor.Location = new System.Drawing.Point(68, 68);
            this.TxtValor.Name = "TxtValor";
            this.TxtValor.Size = new System.Drawing.Size(100, 20);
            this.TxtValor.TabIndex = 2;
            this.TxtValor.TextChanged += new System.EventHandler(this.TxtValor_TextChanged);
            this.TxtValor.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtValor_KeyPress);
            // 
            // BtnSair
            // 
            this.BtnSair.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSair.Location = new System.Drawing.Point(658, 191);
            this.BtnSair.Name = "BtnSair";
            this.BtnSair.Size = new System.Drawing.Size(75, 23);
            this.BtnSair.TabIndex = 3;
            this.BtnSair.Text = "Sair";
            this.BtnSair.UseVisualStyleBackColor = true;
            this.BtnSair.Click += new System.EventHandler(this.BtnSair_Click);
            // 
            // LblMensal
            // 
            this.LblMensal.AutoSize = true;
            this.LblMensal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblMensal.Location = new System.Drawing.Point(94, 175);
            this.LblMensal.Name = "LblMensal";
            this.LblMensal.Size = new System.Drawing.Size(47, 13);
            this.LblMensal.TabIndex = 4;
            this.LblMensal.Text = "Mensal";
            // 
            // LblAnual
            // 
            this.LblAnual.AutoSize = true;
            this.LblAnual.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblAnual.Location = new System.Drawing.Point(94, 228);
            this.LblAnual.Name = "LblAnual";
            this.LblAnual.Size = new System.Drawing.Size(39, 13);
            this.LblAnual.TabIndex = 5;
            this.LblAnual.Text = "Anual";
            // 
            // TxtMensal
            // 
            this.TxtMensal.Location = new System.Drawing.Point(68, 191);
            this.TxtMensal.Name = "TxtMensal";
            this.TxtMensal.Size = new System.Drawing.Size(100, 20);
            this.TxtMensal.TabIndex = 6;
            this.TxtMensal.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtPrazo_KeyPress);
            // 
            // TxtAnual
            // 
            this.TxtAnual.Location = new System.Drawing.Point(68, 244);
            this.TxtAnual.Name = "TxtAnual";
            this.TxtAnual.Size = new System.Drawing.Size(100, 20);
            this.TxtAnual.TabIndex = 7;
            this.TxtAnual.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtVender_KeyPress);
            // 
            // Lblano
            // 
            this.Lblano.AutoSize = true;
            this.Lblano.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lblano.Location = new System.Drawing.Point(65, 109);
            this.Lblano.Name = "Lblano";
            this.Lblano.Size = new System.Drawing.Size(95, 13);
            this.Lblano.TabIndex = 8;
            this.Lblano.Text = "Ano do Veículo";
            // 
            // TxtAno
            // 
            this.TxtAno.Location = new System.Drawing.Point(68, 125);
            this.TxtAno.Name = "TxtAno";
            this.TxtAno.Size = new System.Drawing.Size(100, 20);
            this.TxtAno.TabIndex = 9;
            // 
            // LblReal
            // 
            this.LblReal.AutoSize = true;
            this.LblReal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblReal.Location = new System.Drawing.Point(65, 304);
            this.LblReal.Name = "LblReal";
            this.LblReal.Size = new System.Drawing.Size(126, 13);
            this.LblReal.TabIndex = 10;
            this.LblReal.Text = "Valor real do veículo";
            // 
            // TxtReal
            // 
            this.TxtReal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtReal.Location = new System.Drawing.Point(68, 320);
            this.TxtReal.Name = "TxtReal";
            this.TxtReal.Size = new System.Drawing.Size(100, 20);
            this.TxtReal.TabIndex = 11;
            // 
            // FrmVeiculo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.TxtReal);
            this.Controls.Add(this.LblReal);
            this.Controls.Add(this.TxtAno);
            this.Controls.Add(this.Lblano);
            this.Controls.Add(this.TxtAnual);
            this.Controls.Add(this.TxtMensal);
            this.Controls.Add(this.LblAnual);
            this.Controls.Add(this.LblMensal);
            this.Controls.Add(this.BtnSair);
            this.Controls.Add(this.TxtValor);
            this.Controls.Add(this.BtnCalcular);
            this.Controls.Add(this.LblValorPago);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmVeiculo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Depreciação de veículos";
            this.Load += new System.EventHandler(this.FrmVeiculo_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblValorPago;
        private System.Windows.Forms.Button BtnCalcular;
        private System.Windows.Forms.TextBox TxtValor;
        private System.Windows.Forms.Button BtnSair;
        private System.Windows.Forms.Label LblMensal;
        private System.Windows.Forms.Label LblAnual;
        private System.Windows.Forms.TextBox TxtMensal;
        private System.Windows.Forms.TextBox TxtAnual;
        private System.Windows.Forms.Label Lblano;
        private System.Windows.Forms.TextBox TxtAno;
        private System.Windows.Forms.Label LblReal;
        private System.Windows.Forms.TextBox TxtReal;
    }
}