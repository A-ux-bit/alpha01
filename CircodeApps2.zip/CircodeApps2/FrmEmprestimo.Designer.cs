﻿
namespace CircodeApps2
{
    partial class FrmEmprestimo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmEmprestimo));
            this.LblValor = new System.Windows.Forms.Label();
            this.LblJuros = new System.Windows.Forms.Label();
            this.LblPrazo = new System.Windows.Forms.Label();
            this.Txtvalor = new System.Windows.Forms.TextBox();
            this.Btncalcular = new System.Windows.Forms.Button();
            this.GrbResposta = new System.Windows.Forms.GroupBox();
            this.Btnsair = new System.Windows.Forms.Button();
            this.TxtPrazo = new System.Windows.Forms.TextBox();
            this.Txtjuros = new System.Windows.Forms.TextBox();
            this.TxtTotal = new System.Windows.Forms.TextBox();
            this.TxtPago = new System.Windows.Forms.TextBox();
            this.TxtMensal = new System.Windows.Forms.TextBox();
            this.LblPagos = new System.Windows.Forms.Label();
            this.LblTotal = new System.Windows.Forms.Label();
            this.LblMensal = new System.Windows.Forms.Label();
            this.GrbResposta.SuspendLayout();
            this.SuspendLayout();
            // 
            // LblValor
            // 
            this.LblValor.AutoSize = true;
            this.LblValor.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblValor.Location = new System.Drawing.Point(9, 9);
            this.LblValor.Name = "LblValor";
            this.LblValor.Size = new System.Drawing.Size(121, 13);
            this.LblValor.TabIndex = 0;
            this.LblValor.Text = "Valor do empréstimo";
            // 
            // LblJuros
            // 
            this.LblJuros.AutoSize = true;
            this.LblJuros.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblJuros.Location = new System.Drawing.Point(33, 61);
            this.LblJuros.Name = "LblJuros";
            this.LblJuros.Size = new System.Drawing.Size(58, 13);
            this.LblJuros.TabIndex = 1;
            this.LblJuros.Text = "Juros (%)";
            // 
            // LblPrazo
            // 
            this.LblPrazo.AutoSize = true;
            this.LblPrazo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblPrazo.Location = new System.Drawing.Point(22, 114);
            this.LblPrazo.Name = "LblPrazo";
            this.LblPrazo.Size = new System.Drawing.Size(78, 13);
            this.LblPrazo.TabIndex = 2;
            this.LblPrazo.Text = "Prazo (anos)";
            // 
            // Txtvalor
            // 
            this.Txtvalor.Location = new System.Drawing.Point(12, 25);
            this.Txtvalor.Name = "Txtvalor";
            this.Txtvalor.Size = new System.Drawing.Size(100, 20);
            this.Txtvalor.TabIndex = 3;
            this.Txtvalor.TextChanged += new System.EventHandler(this.Txtvalor_TextChanged);
            this.Txtvalor.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Txtvalor_KeyPress);
            // 
            // Btncalcular
            // 
            this.Btncalcular.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btncalcular.Location = new System.Drawing.Point(647, 61);
            this.Btncalcular.Name = "Btncalcular";
            this.Btncalcular.Size = new System.Drawing.Size(75, 23);
            this.Btncalcular.TabIndex = 4;
            this.Btncalcular.Text = "Calcular";
            this.Btncalcular.UseVisualStyleBackColor = true;
            this.Btncalcular.Click += new System.EventHandler(this.Btncalcular_Click);
            // 
            // GrbResposta
            // 
            this.GrbResposta.Controls.Add(this.TxtTotal);
            this.GrbResposta.Controls.Add(this.TxtPago);
            this.GrbResposta.Controls.Add(this.TxtMensal);
            this.GrbResposta.Controls.Add(this.LblPagos);
            this.GrbResposta.Controls.Add(this.LblTotal);
            this.GrbResposta.Controls.Add(this.LblMensal);
            this.GrbResposta.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GrbResposta.Location = new System.Drawing.Point(192, 24);
            this.GrbResposta.Name = "GrbResposta";
            this.GrbResposta.Size = new System.Drawing.Size(300, 266);
            this.GrbResposta.TabIndex = 5;
            this.GrbResposta.TabStop = false;
            this.GrbResposta.Text = "Demostrativo";
            // 
            // Btnsair
            // 
            this.Btnsair.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btnsair.Location = new System.Drawing.Point(647, 127);
            this.Btnsair.Name = "Btnsair";
            this.Btnsair.Size = new System.Drawing.Size(75, 23);
            this.Btnsair.TabIndex = 6;
            this.Btnsair.Text = "Sair";
            this.Btnsair.UseVisualStyleBackColor = true;
            this.Btnsair.Click += new System.EventHandler(this.Btnsair_Click);
            // 
            // TxtPrazo
            // 
            this.TxtPrazo.Location = new System.Drawing.Point(12, 130);
            this.TxtPrazo.Name = "TxtPrazo";
            this.TxtPrazo.Size = new System.Drawing.Size(100, 20);
            this.TxtPrazo.TabIndex = 7;
            this.TxtPrazo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtPrazo_KeyPress);
            // 
            // Txtjuros
            // 
            this.Txtjuros.Location = new System.Drawing.Point(12, 77);
            this.Txtjuros.Name = "Txtjuros";
            this.Txtjuros.Size = new System.Drawing.Size(100, 20);
            this.Txtjuros.TabIndex = 8;
            this.Txtjuros.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Txtjuros_KeyPress);
            // 
            // TxtTotal
            // 
            this.TxtTotal.Location = new System.Drawing.Point(97, 131);
            this.TxtTotal.Name = "TxtTotal";
            this.TxtTotal.Size = new System.Drawing.Size(100, 20);
            this.TxtTotal.TabIndex = 14;
            // 
            // TxtPago
            // 
            this.TxtPago.Location = new System.Drawing.Point(97, 184);
            this.TxtPago.Name = "TxtPago";
            this.TxtPago.Size = new System.Drawing.Size(100, 20);
            this.TxtPago.TabIndex = 13;
            // 
            // TxtMensal
            // 
            this.TxtMensal.Location = new System.Drawing.Point(97, 79);
            this.TxtMensal.Name = "TxtMensal";
            this.TxtMensal.Size = new System.Drawing.Size(100, 20);
            this.TxtMensal.TabIndex = 12;
            // 
            // LblPagos
            // 
            this.LblPagos.AutoSize = true;
            this.LblPagos.Location = new System.Drawing.Point(109, 168);
            this.LblPagos.Name = "LblPagos";
            this.LblPagos.Size = new System.Drawing.Size(75, 13);
            this.LblPagos.TabIndex = 11;
            this.LblPagos.Text = "Juros pagos";
            this.LblPagos.Click += new System.EventHandler(this.label4_Click);
            // 
            // LblTotal
            // 
            this.LblTotal.AutoSize = true;
            this.LblTotal.Location = new System.Drawing.Point(109, 113);
            this.LblTotal.Name = "LblTotal";
            this.LblTotal.Size = new System.Drawing.Size(68, 13);
            this.LblTotal.TabIndex = 10;
            this.LblTotal.Text = "Total pago";
            // 
            // LblMensal
            // 
            this.LblMensal.AutoSize = true;
            this.LblMensal.Location = new System.Drawing.Point(94, 60);
            this.LblMensal.Name = "LblMensal";
            this.LblMensal.Size = new System.Drawing.Size(113, 13);
            this.LblMensal.TabIndex = 9;
            this.LblMensal.Text = "Pagamento mensal";
            // 
            // FrmEmprestimo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 343);
            this.Controls.Add(this.Txtjuros);
            this.Controls.Add(this.TxtPrazo);
            this.Controls.Add(this.Btnsair);
            this.Controls.Add(this.GrbResposta);
            this.Controls.Add(this.Btncalcular);
            this.Controls.Add(this.Txtvalor);
            this.Controls.Add(this.LblPrazo);
            this.Controls.Add(this.LblJuros);
            this.Controls.Add(this.LblValor);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmEmprestimo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cálculo de empréstimo";
            this.Load += new System.EventHandler(this.FrmEmprestimo_Load);
            this.GrbResposta.ResumeLayout(false);
            this.GrbResposta.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblValor;
        private System.Windows.Forms.Label LblJuros;
        private System.Windows.Forms.Label LblPrazo;
        private System.Windows.Forms.TextBox Txtvalor;
        private System.Windows.Forms.Button Btncalcular;
        private System.Windows.Forms.GroupBox GrbResposta;
        private System.Windows.Forms.TextBox TxtTotal;
        private System.Windows.Forms.TextBox TxtPago;
        private System.Windows.Forms.TextBox TxtMensal;
        private System.Windows.Forms.Label LblPagos;
        private System.Windows.Forms.Label LblTotal;
        private System.Windows.Forms.Label LblMensal;
        private System.Windows.Forms.Button Btnsair;
        private System.Windows.Forms.TextBox TxtPrazo;
        private System.Windows.Forms.TextBox Txtjuros;
    }
}