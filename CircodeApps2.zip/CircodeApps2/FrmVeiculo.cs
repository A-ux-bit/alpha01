﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CircodeApps2
{
    public partial class FrmVeiculo : Form
    {
        public FrmVeiculo()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FrmVeiculo_Load(object sender, EventArgs e)
        {
            this.ActiveControl = TxtValor;
            TxtValor.Focus();
        }

        private void TxtValor_TextChanged(object sender, EventArgs e)
        {
          
        }

        private void TxtValor_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && e.KeyChar != (char)8 && e.KeyChar != (char)44)
            {
                e.Handled = true;
            }
        }

        private void TxtPrazo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && e.KeyChar != (char)8 && e.KeyChar != (char)44)
            {
                e.Handled = true;
            }
        }

        private void TxtVender_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && e.KeyChar != (char)8 && e.KeyChar != (char)44)
            {
                e.Handled = true;
            }
        }

        private void BtnCalcular_Click(object sender, EventArgs e)
        {
            double dano, dmes, valor, preço;
            int anoatual, anoveículo, resultado;
            anoveículo = Convert.ToInt32(TxtAno.Text);
            anoatual = DateTime.Now.Year;
            resultado = anoatual - anoveículo;
            valor = Convert.ToDouble(TxtValor.Text);
            dano = valor / resultado;
            dmes = valor / 12;
            preço = (valor - dano);
            TxtAnual.Text = "R$" + dano.ToString("N2");
            TxtMensal.Text = "R$" + dmes.ToString("N2");
            TxtReal.Text = "R$" + preço.ToString("N2");
            TxtValor.Text = "";
            TxtAno.Text = "";
            this.ActiveControl = TxtValor;
            TxtValor.Focus();
        }

        private void LblValorPago_Click(object sender, EventArgs e)
        {

        }
    }
}
