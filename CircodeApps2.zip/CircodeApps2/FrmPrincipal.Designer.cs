﻿namespace CircodeApps2
{
    partial class FrmPrincipal
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmPrincipal));
            this.BtnSair = new System.Windows.Forms.Button();
            this.PicBIMC = new System.Windows.Forms.PictureBox();
            this.LblIMC = new System.Windows.Forms.Label();
            this.LblData = new System.Windows.Forms.Label();
            this.PicBData = new System.Windows.Forms.PictureBox();
            this.LblViagem = new System.Windows.Forms.Label();
            this.PicBViagem = new System.Windows.Forms.PictureBox();
            this.LblEmpréstimo = new System.Windows.Forms.Label();
            this.PicBEemprestimo = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.LblMoedas = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.ImgBMega = new System.Windows.Forms.Label();
            this.PicBVeiculo = new System.Windows.Forms.PictureBox();
            this.LblVeiculo = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.PicBIMC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicBData)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicBViagem)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicBEemprestimo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicBVeiculo)).BeginInit();
            this.SuspendLayout();
            // 
            // BtnSair
            // 
            this.BtnSair.BackColor = System.Drawing.Color.DarkRed;
            this.BtnSair.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSair.ForeColor = System.Drawing.SystemColors.Control;
            this.BtnSair.Location = new System.Drawing.Point(637, 376);
            this.BtnSair.Name = "BtnSair";
            this.BtnSair.Size = new System.Drawing.Size(151, 62);
            this.BtnSair.TabIndex = 0;
            this.BtnSair.Text = "Sair";
            this.BtnSair.UseVisualStyleBackColor = false;
            this.BtnSair.UseWaitCursor = true;
            this.BtnSair.Click += new System.EventHandler(this.BtnSair_Click);
            // 
            // PicBIMC
            // 
            this.PicBIMC.Image = global::CircodeApps2.Properties.Resources.imc;
            this.PicBIMC.Location = new System.Drawing.Point(13, 13);
            this.PicBIMC.Name = "PicBIMC";
            this.PicBIMC.Size = new System.Drawing.Size(152, 138);
            this.PicBIMC.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PicBIMC.TabIndex = 1;
            this.PicBIMC.TabStop = false;
            this.PicBIMC.UseWaitCursor = true;
            this.PicBIMC.Click += new System.EventHandler(this.PicBIMC_Click);
            // 
            // LblIMC
            // 
            this.LblIMC.AutoSize = true;
            this.LblIMC.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblIMC.Location = new System.Drawing.Point(22, 154);
            this.LblIMC.Name = "LblIMC";
            this.LblIMC.Size = new System.Drawing.Size(130, 20);
            this.LblIMC.TabIndex = 2;
            this.LblIMC.Text = "Cálculo do IMC";
            this.LblIMC.UseWaitCursor = true;
            // 
            // LblData
            // 
            this.LblData.AutoSize = true;
            this.LblData.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblData.Location = new System.Drawing.Point(213, 154);
            this.LblData.Name = "LblData";
            this.LblData.Size = new System.Drawing.Size(137, 20);
            this.LblData.TabIndex = 4;
            this.LblData.Text = "Cálculo da Data";
            this.LblData.UseWaitCursor = true;
            // 
            // PicBData
            // 
            this.PicBData.Image = global::CircodeApps2.Properties.Resources.calendario;
            this.PicBData.Location = new System.Drawing.Point(204, 13);
            this.PicBData.Name = "PicBData";
            this.PicBData.Size = new System.Drawing.Size(152, 138);
            this.PicBData.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PicBData.TabIndex = 3;
            this.PicBData.TabStop = false;
            this.PicBData.UseWaitCursor = true;
            this.PicBData.Click += new System.EventHandler(this.PicBData_Click);
            // 
            // LblViagem
            // 
            this.LblViagem.AutoSize = true;
            this.LblViagem.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblViagem.Location = new System.Drawing.Point(397, 155);
            this.LblViagem.Name = "LblViagem";
            this.LblViagem.Size = new System.Drawing.Size(158, 20);
            this.LblViagem.TabIndex = 6;
            this.LblViagem.Text = "Cálculo da Viagem";
            this.LblViagem.UseWaitCursor = true;
            // 
            // PicBViagem
            // 
            this.PicBViagem.Image = global::CircodeApps2.Properties.Resources.viagem2;
            this.PicBViagem.Location = new System.Drawing.Point(399, 14);
            this.PicBViagem.Name = "PicBViagem";
            this.PicBViagem.Size = new System.Drawing.Size(152, 138);
            this.PicBViagem.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PicBViagem.TabIndex = 5;
            this.PicBViagem.TabStop = false;
            this.PicBViagem.UseWaitCursor = true;
            this.PicBViagem.Click += new System.EventHandler(this.PicBViagem_Click);
            // 
            // LblEmpréstimo
            // 
            this.LblEmpréstimo.AutoSize = true;
            this.LblEmpréstimo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblEmpréstimo.Location = new System.Drawing.Point(603, 155);
            this.LblEmpréstimo.Name = "LblEmpréstimo";
            this.LblEmpréstimo.Size = new System.Drawing.Size(191, 20);
            this.LblEmpréstimo.TabIndex = 8;
            this.LblEmpréstimo.Text = "Cálculo de empréstimo";
            this.LblEmpréstimo.UseWaitCursor = true;
            // 
            // PicBEemprestimo
            // 
            this.PicBEemprestimo.Image = global::CircodeApps2.Properties.Resources.emprestimo;
            this.PicBEemprestimo.Location = new System.Drawing.Point(618, 14);
            this.PicBEemprestimo.Name = "PicBEemprestimo";
            this.PicBEemprestimo.Size = new System.Drawing.Size(152, 138);
            this.PicBEemprestimo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PicBEemprestimo.TabIndex = 7;
            this.PicBEemprestimo.TabStop = false;
            this.PicBEemprestimo.UseWaitCursor = true;
            this.PicBEemprestimo.Click += new System.EventHandler(this.PicBEemprestimo_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::CircodeApps2.Properties.Resources.moeda;
            this.pictureBox1.Location = new System.Drawing.Point(13, 224);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(152, 138);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.UseWaitCursor = true;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // LblMoedas
            // 
            this.LblMoedas.AutoSize = true;
            this.LblMoedas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblMoedas.Location = new System.Drawing.Point(-1, 376);
            this.LblMoedas.Name = "LblMoedas";
            this.LblMoedas.Size = new System.Drawing.Size(187, 20);
            this.LblMoedas.TabIndex = 2;
            this.LblMoedas.Text = "Conversão de moedas";
            this.LblMoedas.UseWaitCursor = true;
            this.LblMoedas.Click += new System.EventHandler(this.label1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::CircodeApps2.Properties.Resources.mega_sena;
            this.pictureBox2.Location = new System.Drawing.Point(204, 224);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(152, 138);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 10;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.UseWaitCursor = true;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // ImgBMega
            // 
            this.ImgBMega.AutoSize = true;
            this.ImgBMega.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ImgBMega.Location = new System.Drawing.Point(228, 376);
            this.ImgBMega.Name = "ImgBMega";
            this.ImgBMega.Size = new System.Drawing.Size(100, 20);
            this.ImgBMega.TabIndex = 11;
            this.ImgBMega.Text = "Mega Sena";
            this.ImgBMega.UseWaitCursor = true;
            this.ImgBMega.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // PicBVeiculo
            // 
            this.PicBVeiculo.Image = global::CircodeApps2.Properties.Resources.veiculo;
            this.PicBVeiculo.Location = new System.Drawing.Point(399, 224);
            this.PicBVeiculo.Name = "PicBVeiculo";
            this.PicBVeiculo.Size = new System.Drawing.Size(152, 138);
            this.PicBVeiculo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PicBVeiculo.TabIndex = 12;
            this.PicBVeiculo.TabStop = false;
            this.PicBVeiculo.UseWaitCursor = true;
            this.PicBVeiculo.Click += new System.EventHandler(this.PicBVeiculo_Click);
            // 
            // LblVeiculo
            // 
            this.LblVeiculo.AutoSize = true;
            this.LblVeiculo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblVeiculo.Location = new System.Drawing.Point(377, 376);
            this.LblVeiculo.Name = "LblVeiculo";
            this.LblVeiculo.Size = new System.Drawing.Size(195, 20);
            this.LblVeiculo.TabIndex = 13;
            this.LblVeiculo.Text = "Depreciação de veículo";
            this.LblVeiculo.UseWaitCursor = true;
            // 
            // FrmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.LblVeiculo);
            this.Controls.Add(this.PicBVeiculo);
            this.Controls.Add(this.ImgBMega);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.LblMoedas);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.LblEmpréstimo);
            this.Controls.Add(this.PicBEemprestimo);
            this.Controls.Add(this.LblViagem);
            this.Controls.Add(this.PicBViagem);
            this.Controls.Add(this.LblData);
            this.Controls.Add(this.PicBData);
            this.Controls.Add(this.LblIMC);
            this.Controls.Add(this.PicBIMC);
            this.Controls.Add(this.BtnSair);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "LblEmprestimo";
            this.UseWaitCursor = true;
            this.Load += new System.EventHandler(this.FrmPrincipal_Load);
            ((System.ComponentModel.ISupportInitialize)(this.PicBIMC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicBData)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicBViagem)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicBEemprestimo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicBVeiculo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnSair;
        private System.Windows.Forms.PictureBox PicBIMC;
        private System.Windows.Forms.Label LblIMC;
        private System.Windows.Forms.Label LblData;
        private System.Windows.Forms.PictureBox PicBData;
        private System.Windows.Forms.Label LblViagem;
        private System.Windows.Forms.PictureBox PicBViagem;
        private System.Windows.Forms.Label LblEmpréstimo;
        private System.Windows.Forms.PictureBox PicBEemprestimo;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label LblMoedas;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label ImgBMega;
        private System.Windows.Forms.PictureBox PicBVeiculo;
        private System.Windows.Forms.Label LblVeiculo;
    }
}

