﻿
namespace CircodeApps2
{
    partial class FrmConverter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmConverter));
            this.LblReal = new System.Windows.Forms.Label();
            this.TxtReal = new System.Windows.Forms.TextBox();
            this.Btncalcular = new System.Windows.Forms.Button();
            this.LblDolar = new System.Windows.Forms.Label();
            this.LblIen = new System.Windows.Forms.Label();
            this.LblLibra = new System.Windows.Forms.Label();
            this.LblFranco = new System.Windows.Forms.Label();
            this.TxtDolar = new System.Windows.Forms.TextBox();
            this.TxtFranco = new System.Windows.Forms.TextBox();
            this.TxtLibra = new System.Windows.Forms.TextBox();
            this.TxtIen = new System.Windows.Forms.TextBox();
            this.BtnSair = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LblReal
            // 
            this.LblReal.AutoSize = true;
            this.LblReal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblReal.Location = new System.Drawing.Point(35, 26);
            this.LblReal.Name = "LblReal";
            this.LblReal.Size = new System.Drawing.Size(33, 13);
            this.LblReal.TabIndex = 0;
            this.LblReal.Text = "Real";
            // 
            // TxtReal
            // 
            this.TxtReal.Location = new System.Drawing.Point(12, 42);
            this.TxtReal.Name = "TxtReal";
            this.TxtReal.Size = new System.Drawing.Size(100, 20);
            this.TxtReal.TabIndex = 1;
            this.TxtReal.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtReal_KeyPress);
            // 
            // Btncalcular
            // 
            this.Btncalcular.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btncalcular.Location = new System.Drawing.Point(665, 96);
            this.Btncalcular.Name = "Btncalcular";
            this.Btncalcular.Size = new System.Drawing.Size(75, 23);
            this.Btncalcular.TabIndex = 2;
            this.Btncalcular.Text = "Converter";
            this.Btncalcular.UseVisualStyleBackColor = true;
            this.Btncalcular.Click += new System.EventHandler(this.button1_Click);
            // 
            // LblDolar
            // 
            this.LblDolar.AutoSize = true;
            this.LblDolar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblDolar.Location = new System.Drawing.Point(35, 129);
            this.LblDolar.Name = "LblDolar";
            this.LblDolar.Size = new System.Drawing.Size(37, 13);
            this.LblDolar.TabIndex = 3;
            this.LblDolar.Text = "Dólar";
            // 
            // LblIen
            // 
            this.LblIen.AutoSize = true;
            this.LblIen.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblIen.Location = new System.Drawing.Point(35, 179);
            this.LblIen.Name = "LblIen";
            this.LblIen.Size = new System.Drawing.Size(25, 13);
            this.LblIen.TabIndex = 4;
            this.LblIen.Text = "Ien";
            // 
            // LblLibra
            // 
            this.LblLibra.AutoSize = true;
            this.LblLibra.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblLibra.Location = new System.Drawing.Point(33, 235);
            this.LblLibra.Name = "LblLibra";
            this.LblLibra.Size = new System.Drawing.Size(35, 13);
            this.LblLibra.TabIndex = 5;
            this.LblLibra.Text = "Libra";
            // 
            // LblFranco
            // 
            this.LblFranco.AutoSize = true;
            this.LblFranco.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblFranco.Location = new System.Drawing.Point(33, 289);
            this.LblFranco.Name = "LblFranco";
            this.LblFranco.Size = new System.Drawing.Size(46, 13);
            this.LblFranco.TabIndex = 6;
            this.LblFranco.Text = "Franco";
            // 
            // TxtDolar
            // 
            this.TxtDolar.Location = new System.Drawing.Point(97, 129);
            this.TxtDolar.Name = "TxtDolar";
            this.TxtDolar.Size = new System.Drawing.Size(100, 20);
            this.TxtDolar.TabIndex = 7;
            // 
            // TxtFranco
            // 
            this.TxtFranco.Location = new System.Drawing.Point(97, 282);
            this.TxtFranco.Name = "TxtFranco";
            this.TxtFranco.Size = new System.Drawing.Size(100, 20);
            this.TxtFranco.TabIndex = 8;
            // 
            // TxtLibra
            // 
            this.TxtLibra.Location = new System.Drawing.Point(97, 228);
            this.TxtLibra.Name = "TxtLibra";
            this.TxtLibra.Size = new System.Drawing.Size(100, 20);
            this.TxtLibra.TabIndex = 9;
            // 
            // TxtIen
            // 
            this.TxtIen.Location = new System.Drawing.Point(97, 172);
            this.TxtIen.Name = "TxtIen";
            this.TxtIen.Size = new System.Drawing.Size(100, 20);
            this.TxtIen.TabIndex = 10;
            // 
            // BtnSair
            // 
            this.BtnSair.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSair.Location = new System.Drawing.Point(665, 151);
            this.BtnSair.Name = "BtnSair";
            this.BtnSair.Size = new System.Drawing.Size(75, 23);
            this.BtnSair.TabIndex = 13;
            this.BtnSair.Text = "Sair";
            this.BtnSair.UseVisualStyleBackColor = true;
            // 
            // FrmConverter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.BtnSair);
            this.Controls.Add(this.TxtIen);
            this.Controls.Add(this.TxtLibra);
            this.Controls.Add(this.TxtFranco);
            this.Controls.Add(this.TxtDolar);
            this.Controls.Add(this.LblFranco);
            this.Controls.Add(this.LblLibra);
            this.Controls.Add(this.LblIen);
            this.Controls.Add(this.LblDolar);
            this.Controls.Add(this.Btncalcular);
            this.Controls.Add(this.TxtReal);
            this.Controls.Add(this.LblReal);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmConverter";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Conversão de Real";
            this.Load += new System.EventHandler(this.FrmConverter_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblReal;
        private System.Windows.Forms.TextBox TxtReal;
        private System.Windows.Forms.Button Btncalcular;
        private System.Windows.Forms.Label LblDolar;
        private System.Windows.Forms.Label LblIen;
        private System.Windows.Forms.Label LblLibra;
        private System.Windows.Forms.Label LblFranco;
        private System.Windows.Forms.TextBox TxtDolar;
        private System.Windows.Forms.TextBox TxtFranco;
        private System.Windows.Forms.TextBox TxtLibra;
        private System.Windows.Forms.TextBox TxtIen;
        private System.Windows.Forms.Button BtnSair;
    }
}